package com.javassem.domain;

public class OwnerVO {
	private int ownernum;
	private String ownerid;
	private String ownerpass;
	private String ownername;
	private String ownerbirth;
	private String ownercode;
	private String ownergender;
	private String ownerpn;
	private String ownermail;
	private String ownerdate;
	private String shopaddr;
	private String shopcode;
	
	public int getOwnernum() {
		return ownernum;
	}
	public String getShopaddr() {
		return shopaddr;
	}
	public void setShopaddr(String shopaddr) {
		this.shopaddr = shopaddr;
	}
	public String getShopcode() {
		return shopcode;
	}
	public void setShopcode(String shopcode) {
		this.shopcode = shopcode;
	}
	public void setOwnernum(int ownernum) {
		this.ownernum = ownernum;
	}
	public String getOwnerid() {
		return ownerid;
	}
	public void setOwnerid(String ownerid) {
		this.ownerid = ownerid;
	}
	public String getOwnerpass() {
		return ownerpass;
	}
	public void setOwnerpass(String ownerpass) {
		this.ownerpass = ownerpass;
	}
	public String getOwnername() {
		return ownername;
	}

	
	public void setOwnername(String ownername) {
		this.ownername = ownername;
	}
	public String getOwnerbirth() {
		return ownerbirth;
	}
	public void setOwnerbirth(String ownerbirth) {
		this.ownerbirth = ownerbirth;
	}
	public String getOwnercode() {
		return ownercode;
	}
	public void setOwnercode(String ownercode) {
		this.ownercode = ownercode;
	}
	public String getOwnergender() {
		return ownergender;
	}
	public void setOwnergender(String ownergender) {
		this.ownergender = ownergender;
	}
	public String getOwnerpn() {
		return ownerpn;
	}
	public void setOwnerpn(String ownerpn) {
		this.ownerpn = ownerpn;
	}
	public String getOwnermail() {
		return ownermail;
	}
	public void setOwnermail(String ownermail) {
		this.ownermail = ownermail;
	}
	public String getOwnerdate() {
		return ownerdate;
	}
	public void setOwnerdate(String ownerdate) {
		this.ownerdate = ownerdate;
	}
	
}
