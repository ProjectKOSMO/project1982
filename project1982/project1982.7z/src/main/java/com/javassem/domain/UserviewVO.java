package com.javassem.domain;

public class UserviewVO {

}
