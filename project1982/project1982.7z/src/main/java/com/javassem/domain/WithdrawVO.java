package com.javassem.domain;

public class WithdrawVO {

}
