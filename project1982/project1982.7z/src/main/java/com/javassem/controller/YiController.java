package com.javassem.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.javassem.domain.OwnerVO;

@Controller
//@RequestMapping("owner")
public class YiController {
	
//	@RequestMapping("{step1}.do")
//	public String ownerJoin(@PathVariable String step1){
//		return "/owner/" + step1;
//	}
//	
//	@RequestMapping("owner_login")
//	public void ownerlogin(OwnerVO vo){
//		
//		
//	}
//	
//	@RequestMapping("owner_register")
//	public void owner_register(OwnerVO vo){
//		
//		
//	}

	
}
