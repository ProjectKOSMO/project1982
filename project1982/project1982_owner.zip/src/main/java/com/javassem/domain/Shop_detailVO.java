package com.javassem.domain;

public class Shop_detailVO {

}
