package com.javassem.domain;

public class Deposit_detailsVO {

}
