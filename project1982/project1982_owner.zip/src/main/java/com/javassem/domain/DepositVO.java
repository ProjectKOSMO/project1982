package com.javassem.domain;

public class DepositVO {

}
