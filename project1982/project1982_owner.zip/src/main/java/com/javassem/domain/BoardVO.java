package com.javassem.domain;

public class BoardVO {

}
